import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * Write a description of class DisplayImagePanel here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DisplayImagePanel extends JPanel implements MouseListener
{
    // instance variables - replace the example below with your own
    private int width;
    private int height;
    private Toolkit toolkit;
    int index = 0;
    int x = 400;
    int y = 200;
    Image background;
    Image logo;
    /**
     * Constructor for objects of class DisplayImagePanel
     */
    public DisplayImagePanel()
    {
        setPreferredSize(new Dimension (800, 800));
        toolkit = Toolkit.getDefaultToolkit();
        addMouseListener(this);  
        // provide any initialisation necessary for your JApplet
        background = toolkit.getImage("images\\background.png"); 
        logo = toolkit.getImage("images\\logo.png"); 

        width = getPreferredSize().width;
        height = getPreferredSize().height;
    }

    /**
     * PaintComponent method for JPanel.
     * 
     * @param  g the Graphics object for this applet
     */
    @Override
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        // display BackGround
        g.drawImage(background, 0, 0,width,height, this);
        g.drawImage(logo, 700, 0,100,50, this);
        g.setColor(new Color((float)0,(float)1,(float)1,(float)0.5));
        //display Entry Tiles
        g.fillRoundRect(x,y,50,50,20,20);
        g.fillRoundRect(x + 50,y,50,50,20,20);
        g.fillRoundRect(x+ 100,y,50,50,20,20);
        g.fillRoundRect(x+ 150,y,50,50,20,20);
        g.fillRoundRect(x+ 200,y,50,50,20,20);
        g.fillRoundRect(x+ 250,y,50,50,20,20);
        
        g.setColor(new Color((float)1,(float)1,(float)1,(float)0.75));
        g.fillOval(400,300,50,50);
        g.fillOval(450,300,50,50);
        g.fillOval(500,300,50,50);
        g.fillOval(550,300,50,50);
        g.fillOval(600,300,50,50);
        g.fillOval(650,300,50,50);
        g.fillOval(700,300,50,50);
        
        g.setColor(Color.white);
        x = 400;
        y = 200;
        g.drawRoundRect(x,y,50,50,20,20);
        g.drawRoundRect(x + 50,y,50,50,20,20);
        g.drawRoundRect(x+ 100,y,50,50,20,20);
        g.drawRoundRect(x+ 150,y,50,50,20,20);
        g.drawRoundRect(x+ 200,y,50,50,20,20);
        g.drawRoundRect(x+ 250,y,50,50,20,20);
        
        g.setColor(Color.black);
        g.drawOval(400,300,50,50);
        g.drawOval(450,300,50,50);
        g.drawOval(500,300,50,50);
        g.drawOval(550,300,50,50);
        g.drawOval(600,300,50,50);
        g.drawOval(650,300,50,50);
        g.drawOval(700,300,50,50);
        

        //Display Random Letters Tile
        g.fillRoundRect(400,400,200,100,20,20);
        //System.out.println(index);
    }

    public void mousePressed( MouseEvent e ) { }

    public void mouseReleased( MouseEvent e ) { }

    public void mouseEntered( MouseEvent e ) { }

    public void mouseExited( MouseEvent e ) {}

    public void mouseClicked( MouseEvent e ) {
    }
}
