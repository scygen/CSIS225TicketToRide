import javax.swing.*;
import java.awt.*;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
/**
 * Write a description of class panel here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class panel
{
    protected static boolean isTrue = true;
    protected static String letters = "";

    protected static ArrayList<String> twoLetterWords = new ArrayList<String>();
    protected static ArrayList<String> threeLetterWords = new ArrayList<String>();
    protected static ArrayList<String> fourLetterWords = new ArrayList<String>();
    protected static ArrayList<String> fiveLetterWords = new ArrayList<String>();
    protected static ArrayList<String> sixLetterWords = new ArrayList<String>();
    protected static ArrayList<String> sevenLetterWords = new ArrayList<String>();
    
    private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("TextTwister");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Add the ubiquitous "Hello World" label.
        DisplayImagePanel panel = new DisplayImagePanel();
        frame.getContentPane().add(panel);

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) throws FileNotFoundException{
        int counter = 1;
        File words = new File("Z:\\CS225\\Homework 4\\words.txt");
        Scanner sc = new Scanner(words);
        Scanner scan = new Scanner(System.in);
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    createAndShowGUI();
                }
            });
            
        while(sc.hasNext()){
            if(counter == 1){
                letters =  sc.next();
            }
            else{
                String word = sc.next();
                if(word.length() == 7){
                    sevenLetterWords.add(word);
                }
                else if(word.length() == 6){
                    sixLetterWords.add(word);
                }
                else if(word.length() == 5){
                    fiveLetterWords.add(word);
                }
                else if(word.length() == 4){
                    fourLetterWords.add(word);
                }
                else if(word.length() == 3){
                    threeLetterWords.add(word);
                }
                else if(word.length() == 2){
                    twoLetterWords.add(word);
                }
            }
            counter++;
        }
        
        while(isTrue == true){
            if(twoLetterWords.size() + threeLetterWords.size() + fourLetterWords.size()
            + fiveLetterWords.size() + sixLetterWords.size() + sevenLetterWords.size() == 0){
                System.out.println("You Won! YAY!");
                System.exit(0);
            }
            System.out.println("Letters: " + letters);
            System.out.println("There are currently " + sevenLetterWords.size() + " seven letter words left: ");
            System.out.println("There are currently " + sixLetterWords.size() + " six letter words left: ");
            System.out.println("There are currently " + fiveLetterWords.size() + " five letter words left: ");
            System.out.println("There are currently " + fourLetterWords.size() + " four letter words left: ");
            System.out.println("There are currently " + threeLetterWords.size() + " three letter words left: ");
            System.out.println("There are currently " + twoLetterWords.size() + " two letter words left: ");
            System.out.println("Please enter your word: ");
            String word = scan.next();
            word = word.toUpperCase();
            if(word.length() == 2){
                for(int i = 0; i < twoLetterWords.size(); i++){
                    if(word.equals(twoLetterWords.get(i))){
                        twoLetterWords.remove(word);
                    }
                }
            }
            else if(word.length() == 3){
                for(int i = 0; i < threeLetterWords.size(); i++){
                    if(word.equals(threeLetterWords.get(i))){
                        threeLetterWords.remove(word);
                    }
                }
            }
            else if(word.length() == 4){
                for(int i = 0; i < fourLetterWords.size(); i++){
                    if(word.equals(fourLetterWords.get(i))){
                        fourLetterWords.remove(word);
                    }
                }
            }
            else if(word.length() == 5){
                for(int i = 0; i < fiveLetterWords.size(); i++){
                    if(word.equals(fiveLetterWords.get(i))){
                        fiveLetterWords.remove(word);
                    }
                }
            }
            else if(word.length() == 6){
                for(int i = 0; i < sixLetterWords.size(); i++){
                    if(word.equals(sixLetterWords.get(i))){
                        sixLetterWords.remove(word);
                    }
                }
            }
            else if(word.length() == 7){
                for(int i = 0; i < sevenLetterWords.size(); i++){
                    if(word.equals(sevenLetterWords.get(i))){
                        sevenLetterWords.remove(word);
                    }
                }
            }
            else{
                System.out.println("Sorry the word you entered was not in the database");
            }
        }
        
    }
}
